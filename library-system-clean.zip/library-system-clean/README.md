# LibrarySystem

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 9.1.6.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).

##### Configuration
1. Constants.ts defines default locations for KEYCLOAK server and API Roots.
2. Please note whilst the redirect uri sent to keycloak will work using the default visual code server the angular route will cause a 404 when deployed to TOMCAT or if you package with your spring app in the static directory.   To overcome this update the web.xml and define a default 404 error page with a redirect to index.html this will cause the router to fire correctly on redirect.   Also, see: https://stackoverflow.com/questions/47366792/404-error-on-refresh-for-angularv4-deployed-on-tomcat-server for more details.

add in web.xml // simplest thing to do .. 
<error-page>
        <error-code>404</error-code>
        <location>/Error404.html</location>
</error-page>

Appended: You can try deploying the angular project to the static folder in Spring Boot if you want to run it within the same context.   Again the same redirect error will happen.   I overcame that uisng an error template using Thymeleaf to redirect back to "/" - but this didn't work - the tomcat solution works.

3. The angular interceptor will append the bearer token to all api calls.  
   ** You can see the token if you inspect the api call and look at the headers.
   ** My spring project didn't pick up the headers though.
4. Use ng build --prod to create package. [ You may need to remove the / in the index.html file ]
5. Modify angular.js to point your package to the appropriate directory - I did this directly to my tomcat webapps directoring in the ROOT folder.
6. I have yet to get the interceptor to work when calling the API running in eclipse even though I believe I've addressed the CORS errors. - hence trying to deploy both to TOMCAT or in the embedded server in eclipse.
