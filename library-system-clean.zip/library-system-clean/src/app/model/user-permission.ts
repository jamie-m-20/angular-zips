export class UserPermission {
  userProfileId: string;
  projectId: number;
  value: string;
}
