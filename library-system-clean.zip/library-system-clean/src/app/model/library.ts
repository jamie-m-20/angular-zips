export interface Library {
  id: number;
  name: string;
}

export interface LibraryResolved {
  library: Library;
  error?: any;
}
