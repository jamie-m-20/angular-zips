export class Constants {

  // In dev mode - no root
  public static clientRoot = 'http://localhost:4200/';
  // In prod mode - with root
  //public static clientRoot = 'http://localhost:4200/library/';

  //public static apiRoot = 'http://localhost:8085/library-management/';
  public static apiRoot = 'http://localhost:8080/api/';

  // KEYCLOAK REAM keycloak angular Docker 9998 (User karri/karri - public)
  public static stsAuthority = 'http://localhost:9998/auth/realms/keycloak-angular-auth';
  public static clientId = 'tasks';

  // KEYCLOAK REAM keycloak angular Docker 9998 (User karri/karri - confidential PKCE)
  // public static stsAuthority = 'http://localhost:9998/auth/realms/keycloak-angular-auth';
  // public static clientId = 'todo-ui';
}
