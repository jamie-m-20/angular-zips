import { HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { from, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Constants } from '../constants';
import { AuthService } from './auth-service.component';
//import { fromPromise } from 'rxjs/observable/fromPromise';

@Injectable()
export class AuthInterceptorService implements HttpInterceptor {

  private _token;

  constructor(private _authService: AuthService, private _router: Router) {
    this.resolveAccessToken();
   }

  private resolveAccessToken() {
    this._authService.getAccessToken().then(
      (tokenData) => {
        if (tokenData == null) {
        } else {
          this._token = tokenData;
        }
      }
    ).catch((error) => {
    });
  }

  // intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
  //   return from(this.handleAccess(request, next));
  // }

  // private async handleAccess(request: HttpRequest<any>, next: HttpHandler): Promise<HttpEvent<any>> {
  //   const token = await this._authService.getAccessToken();
  //   console.log('Token: ' + token);
  //   let changedRequest = request;
  //   // HttpHeader object immutable - copy values
  //   const headerSettings: {[name: string]: string | string[]; } = {};

  //   for (const key of request.headers.keys()) {
  //     headerSettings[key] = request.headers.getAll(key);
  //   }
  //   if (token) {
  //     headerSettings['Authorization'] = 'Bearer ' + token;
  //   }
  //   headerSettings['Content-Type'] = 'application/json';
  //   const newHeader = new HttpHeaders(headerSettings);

  //   changedRequest = request.clone({
  //     headers: newHeader});
  //   return next.handle(changedRequest).toPromise();
  // }

  // Access-Control-Allow-Origin
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (req.url.startsWith(Constants.apiRoot)) {
      console.log("Intercepting http");
      return from(this._authService.getAccessToken().then(token => {
        this.resolveAccessToken();
        console.log('Token: ' + this._token);
        const headers = new HttpHeaders()
          .set('Authorization', `Bearer ${this._token}`)
          //.set('Access-Control-Expose-Headers', 'Authorization, Access-Control-Allow-Headers')
          .set('Access-Control-Allow-Origin','*');
        console.log("headers: " + headers.keys);
        const authReq = req.clone({
          headers
        });
        console.log('URL: ' + authReq.headers);
        return next.handle(authReq).pipe(tap(_ => { }, error => {
          var respError = error as HttpErrorResponse;
          if (respError && (respError.status === 401 || respError.status === 403)) {
            this._router.navigate(['/unauthorized']);
          }
        })).toPromise();
      }));
    }
    else {
      return next.handle(req);
    }
  }

  // intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
  //   if (req.url.startsWith(Constants.apiRoot)) {
  //     this.resolveAccessToken();
  //     console.log('Token: ' + this._token);
  //     const headers = new HttpHeaders().set('Authorization', `Bearer ${this._token}`).set('Access-Control-Allow-Headers','*');
  //     const modified = req.clone({setHeaders: {'Custom-Header-2': '2'}});
  //     console.log('modified: ' + modified.headers);

  //     let tokenizedReq = req.clone({
  //       headers: req.headers.set('Authorization','Bearer xx.yy.zz'),
  //     })

  //     console.log('Token Req: ' + tokenizedReq.headers);

  //     return next.handle(tokenizedReq);
  //   } else {
  //     return next.handle(req);
  //   }
  // }

 }

@Injectable()
export class I1 implements HttpInterceptor {
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        console.log('Interceptor: I1');
        const modified = req.clone({setHeaders: {'Custom-Header-1': '1'}});
        return next.handle(modified);
    }
}

@Injectable()
export class I2 implements HttpInterceptor {
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        console.log('Interceptor: I2');
        const modified = req.clone({setHeaders: {'Custom-Header-2': '2'}});
        return next.handle(modified);
    }
}
