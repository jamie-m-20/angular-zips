import { NgModule } from '@angular/core';
import { AuthService } from './auth-service.component';
import { LibraryServiceComponent } from '../library-service/library-service.component';
import { ClientServiceComponent } from '../client-service/client-service.component';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptorService, I1, I2 } from './auth-interceptor.service';
import { AdminRouteGuard } from './admin-route-guard';
import { ProfileComponent } from './profile.component';
import { LoggingInterceptor } from './LoggingInterceptor';

//Interceptors
export const httpInterceptorProviders = [
  { provide: HTTP_INTERCEPTORS, useClass: I1, multi: true },
  { provide: HTTP_INTERCEPTORS, useClass: I2, multi: true },
  { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptorService, multi: true },
  { provide: HTTP_INTERCEPTORS, useClass: LoggingInterceptor, multi: true }
];

@NgModule({
  imports: [],
  exports: [],
  declarations: [ProfileComponent],
  providers: [
      AuthService,
      LibraryServiceComponent,
      ClientServiceComponent,
      AdminRouteGuard,
      httpInterceptorProviders
  ],
})

export class CoreModule { }

