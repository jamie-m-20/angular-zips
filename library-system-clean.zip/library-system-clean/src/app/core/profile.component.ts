import { Component, OnInit } from '@angular/core';
import { AuthService } from './auth-service.component';
import { SharedModule } from '../shared/shared.module';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: []
})

export class ProfileComponent implements OnInit {

  public accessToken;
  public statusMessage;
  public userClaims;
  public user;
  //public userObject;

  constructor(private _authService: AuthService) { }

  ngOnInit(): void {
    if (this._authService.isLoggedIn) {
      console.log('ProfileComponent::ngOnit() User is logged in and ng init in profile');
      this.resolveAccessToken();
      this.resolveUserClaims();
      this.resolveUser();
    } else {
      console.log('ProfileComponent::ngOnit() User is not logged in ngOnit profile');
      this.statusMessage = "ProfileComponent::ngOnit() is not logged in - cannot get access token";
    }
  }

  private resolveAccessToken() {
    this._authService.getAccessToken().then(
      (tokenData) => {
        if (tokenData == null) {
          console.log('ProfileComponent::resolveAccesToken() not set')
          this.statusMessage += "Access token is not set\n";
        } else {
          console.log('ProfileComponent::resolveAccesToken() Setting access token:\n' + tokenData);
          this.accessToken = tokenData;
        }
      }
    ).catch((error) => {
      this.statusMessage += "An error occured fetching the access token\n";
      console.log('ProfileComponent::resolveAccesToken()' + this.statusMessage);
    });
  }

  private resolveUserClaims() {
    this._authService.getUserProfile().then(
      (profileData) => {
         if(profileData == null) {
          console.log('ProfileComponent::resolveClaims() user claims not found\n');
          this.statusMessage += "User claims are not set\n";
         } else {
           console.log('ProfileComponent::resolveAccesClaims() Setting user claims\n' + profileData);
          this.userClaims = JSON.stringify(profileData);
         }
      }
    ).catch((error) => {
      this.statusMessage += "An error occured fetching the user profile data\n";
    });
  }

  private resolveUser() {
    this._authService.getUser().then(
      (userData) => {
         if(userData == null) {
          console.log('ProfileComponent::resolveAccesUser() User is not set in resolve User');
          this.statusMessage += "User is not set\n";
         } else {
          console.log('ProfileComponent::resolveUser() User is resolved\n');
          this.user = JSON.stringify(userData);
          console.log(this.user);
         }
      }
    ).catch((error) => {
      this.statusMessage += "An error occured fetching the user profile data\n";
    });
  }
}
