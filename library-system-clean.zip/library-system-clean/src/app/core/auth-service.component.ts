import { Injectable } from '@angular/core';
import { CoreModule } from './core.module';
import { UserManager, User } from 'oidc-client';
import { Constants } from '../constants';
import { Subject } from 'rxjs';
import { AuthContext } from '../model/auth-context';
import { HttpClient } from '@angular/common/http';

//@Injectable({ providedIn: CoreModule })
@Injectable()
export class AuthService {
  private _userManager: UserManager;
  private _user: User;
  private _loginChangedSubject = new Subject<boolean>();
  private _token;

  loginChanged = this._loginChangedSubject.asObservable();
  authContext: AuthContext;

  constructor(private _httpClient: HttpClient) {

    console.log('Client Root' + Constants.clientRoot);
    const stsSettings = {
      authority: Constants.stsAuthority,
      client_id: Constants.clientId,
      redirect_uri: `${Constants.clientRoot}signin-callback`,
      scope: 'openid email profile',
      response_type: 'code',
      post_logout_redirect_uri: `${Constants.clientRoot}signout-callback`,
      loadUserInfo: true,
      metadata: {
        issuer: `${Constants.stsAuthority}`,
        authorization_endpoint: `${Constants.stsAuthority}/protocol/openid-connect/auth`,
        jwks_uri: `${Constants.stsAuthority}/.protocol/openid-connect/certs`,
        token_endpoint: `${Constants.stsAuthority}/protocol/openid-connect/token`,
        userinfo_endpoint: `${Constants.stsAuthority}/protocol/openid-connect/userinfo`,
        end_session_endpoint: `${Constants.stsAuthority}/protocol/openid-connect/logout?${Constants.clientId}&returnTo=${encodeURI(Constants.clientRoot)}signout-callback`
      }
    };
    this._userManager = new UserManager(stsSettings);
    this._userManager.events.addAccessTokenExpired(_ => {
      this._loginChangedSubject.next(false);
    });
    this._userManager.events.addUserLoaded(user => {
      if (this._user !== user) {
        this._user = user;
        //this.loadSecurityContext();
        this._loginChangedSubject.next(!!user && !user.expired);
      }
    });
  }

  login() {
    console.log('logging in and redirecting...');
    return this._userManager.signinRedirect();
  }

  isLoggedIn(): Promise<boolean> {
    return this._userManager.getUser().then(user => {
      const userCurrent = !!user && !user.expired;
      if (this._user !== user) {
        this._loginChangedSubject.next(userCurrent);
      }
      this._user = user;
      return userCurrent;
    });
  }

  completeLogin() {
    console.log('completing log in');
    return this._userManager.signinRedirectCallback().then(user => {
      console.log('setting user context');
      this._user = user;
      this._loginChangedSubject.next(!!user && !user.expired);
      return user;
    });
  }

  logout() {
    console.log('Logging out client and redirecting...');
    this._userManager.signoutRedirect();
  }

  completeLogout() {
    console.log('Completing the logout');
    this._user = null;
    return this._userManager.signoutRedirectCallback();
  }

  getUser() {
    return this._userManager.getUser().then(user => {
      if (!!user && !user.expired) {
        console.log('AuthService::getUser() returning user');
        return user;
      }
      else {
        console.log('AuthService::getUser() user not fetched: ' + user);
        return null;
      }
    });
  }

  getUserProfile() {
    return this._userManager.getUser().then(user => {
      if (!!user && !user.expired) {
        console.log('AuthService::getUserProfile() returning profile');
        return user.profile;
      }
      else {
        console.log('AuthService::getUserProfile() returning null profile');
        return null;
      }
    });
  }

  getToken() {
    return this._token;
  }

  getAccessToken() {
    return this._userManager.getUser().then(user => {
      if (!!user && !user.expired) {
        this._token = user.access_token;
        return user.access_token;
      }
      else {
        return null;
      }
    });
  }

  loadSecurityContext() {
    this._httpClient
      .get<AuthContext>(`${Constants.stsAuthority}/Projects/AuthContext`)
      .subscribe(
        context => {
          this.authContext = new AuthContext();
          this.authContext.claims = context.claims;
          this.authContext.userProfile = context.userProfile;
        },
        error => console.error(error)
      );
  }

}
