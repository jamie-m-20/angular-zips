import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
//import { LibraryServiceComponent } from './library-service/library-service.component';
import { ClientServiceComponent } from './client-service/client-service.component';
import { SigninRedirectCallbackComponent } from './home/signin-redirect-callback.component';
import { SignoutRedirectCallbackComponent } from './home/signout-redirect-callback.component';
import { UnauthorizedComponent } from './home/unauthorized.component';
import { ProfileComponent } from './core/profile.component';


const routes: Routes = [
  //{ path: 'library-services', component: LibraryServiceComponent },
  {
    path: 'library-services',
    loadChildren: () =>
      import('./library-service/library-service.module').then(m => m.LibraryServiceModule)
  },
  { path: 'client-services', component: ClientServiceComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'signin-callback', component: SigninRedirectCallbackComponent },
  { path: 'signout-callback', component: SignoutRedirectCallbackComponent },
  { path: 'unauthorized', component: UnauthorizedComponent },
  { path: '', component: HomeComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
