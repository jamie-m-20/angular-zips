import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LibraryService } from '../library-service/library.service';
import { IProduct } from '../model/products';
import { Library } from '../model/library';

@Component({
  templateUrl: './client-service.component.html',
  styleUrls: []
})
export class ClientServiceComponent implements OnInit {

  pageTitle = "Product List";
  errorMessage = "";
  libraries: Library[] = [];

  constructor(private libraryService: LibraryService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    console.log('Fetching libraries from service');
    this.libraryService.getLibraries().subscribe({
      next: libraries => {
        this.libraries = libraries;
      },
      error: err => this.errorMessage = err
    });
  }

}
