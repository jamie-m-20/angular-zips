import { Component, OnInit } from '@angular/core';
import { AuthService } from './core/auth-service.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: []
})
export class AppComponent implements OnInit {
  isLoggedIn = false;

  constructor(private _authService: AuthService) {
    this._authService.loginChanged.subscribe(loggedIn => {
      this.isLoggedIn = loggedIn;
    })
  }

  ngOnInit() {
    console.log('ngOnInit - app.component.ts');
    this._authService.isLoggedIn().then(loggedIn => {
     this.isLoggedIn = loggedIn;
    })
  }

  profile() {

  }

  login() {
    console.log('login() -- app.component.ts');
    this._authService.login();
  }

  logout() {
    this._authService.logout();
  }

  isAdmin() {
    return this._authService.authContext && this._authService.authContext.isAdmin;
  }
}
