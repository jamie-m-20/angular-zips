import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LibraryServiceComponent } from './library-service.component';
import { SharedModule } from '../shared/shared.module';
import { LibraryListComponent } from './library-list.component';
import { LibraryDetailComponent } from './library-detail.component';
import { LibraryResolverService } from './library-resolver.service';
import { LibraryEditComponent } from './library-edit/library-edit.component';

// This is a component less route -- add component to the path to asociate with template to use for the path.
@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild([
      {
        path: '',
        component: LibraryListComponent
      },
      {
        path: ':id',
        component: LibraryDetailComponent,
        resolve: { resolvedData: LibraryResolverService }
      }
    ])
  ],
  declarations: [
    LibraryServiceComponent,
    LibraryListComponent,
    LibraryDetailComponent,
    LibraryEditComponent,
  ]
})
export class LibraryServiceModule { }
