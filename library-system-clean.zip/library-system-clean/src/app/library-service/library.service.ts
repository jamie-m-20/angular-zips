import { Injectable, SkipSelf } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { Library } from '../model/library';
import { tap, catchError } from 'rxjs/operators';
import { Constants } from '../constants';
import { IProduct } from '../model/products';

@Injectable({
  providedIn: 'root'
})
export class LibraryService {

  constructor(private http: HttpClient) { }

  getProducts(): Observable<IProduct[]> {
    return this.http.get<IProduct[]>(`${Constants.apiRoot}products/`).pipe(
      tap(data => console.log('All: ' + JSON.stringify(data))),
        catchError(this.handleError)
    );
  }

  getLibraries(): Observable<Library[]> {

    return this.http.get<Library[]>(`${Constants.apiRoot}resolutions`).pipe(
        tap(data => console.log(JSON.stringify(data))),
        catchError(this.handleError)
      );

  }

  getLibrary(id: number): Observable<Library> {
    const url = `${Constants.apiRoot}api/library/${id}`;
    console.log("Fetching library: " + url);
    return this.http.get<Library>(url).pipe(
      tap(data => console.log('getLibrary: ' + JSON.stringify(data))),
        catchError(this.handleError)
    );
  }

  private handleError(err) {
    // in a real world app, we may send the server to some remote logging infrastructure
    // instead of just logging it to the console
    let errorMessage: string;
    if (err.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMessage = `Backend returned code ${err.status}: ${err.body.error}`;
    }
    console.error(err);
    return throwError(errorMessage);
  }
}
