import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { LibraryResolved } from '../model/library';
import { LibraryService } from './library.service';
import { Observable, of } from 'rxjs';
import { Pipe, PipeTransform } from '@angular/core';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class LibraryResolverService implements Resolve<LibraryResolved> {

  constructor(private libraryServce: LibraryService) { }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<LibraryResolved> {

    const id = route.paramMap.get("id");
    if(isNaN(+id)) {
      const message = `Library id was not a number: ${id}`;
      console.error(message);
      return of({ library: null, error: message });
    }

    return this.libraryServce.getLibrary(+id)
    .pipe(
      map(library => ({ library: library })),
      catchError(error => {
        const message = `Retrieval error: ${error}`;
        console.error(message);
        return of({ library: null, error: message });
      })
    );

  }


}
