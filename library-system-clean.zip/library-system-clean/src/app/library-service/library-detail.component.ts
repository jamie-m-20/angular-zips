import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LibraryResolved, Library } from '../model/library';

@Component({
  templateUrl: './library-detail.component.html',
  styleUrls: []
})
export class LibraryDetailComponent implements OnInit {

  pageTitle = 'Library Detail';
  library: Library;
  errorMessage: string;

  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void {
    const resolvedData: LibraryResolved = this.route.snapshot.data['resolvedData'];
    this.errorMessage = resolvedData.error;
    this.onLibraryRetrieved(resolvedData.library);
  }

  onLibraryRetrieved(library: Library): void {
    this.library = library;

    if (this.library) {
      this.pageTitle = `Library Detail: ${this.library.name}`;
    } else {
      this.pageTitle = 'No Library found';
    }
  }
}
