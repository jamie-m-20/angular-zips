import { Component, OnInit } from '@angular/core';

@Component({
  //selector: 'app-library-service',
  templateUrl: './library-service.component.html',
  styleUrls: ['./library-service.component.scss']
})
export class LibraryServiceComponent implements OnInit {

  typesOfShoes: string[] = ['Boots', 'Clogs', 'Loafers', 'Moccasins', 'Sneakers'];

  constructor() { }

  ngOnInit(): void {
  }

}
