import { Component, OnInit } from '@angular/core';
import { LibraryService } from './library.service';
import { ActivatedRoute } from '@angular/router';
import { Library } from '../model/library';

@Component({
  selector: 'app-library-list',
  templateUrl: './library-list.component.html',
  styleUrls: []
})
export class LibraryListComponent implements OnInit {

  pageTitle = "Library List";
  errorMessage = "";
  libraries: Library[] = [];

  displayedColumns: string[] = ['id', 'name'];

  constructor(private libraryService: LibraryService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    console.log('Fetching libraries from service');
    this.libraryService.getLibraries().subscribe({
      next: libraries => {
        this.libraries = libraries;
      },
      error: err => this.errorMessage = err
    });
  }

}
